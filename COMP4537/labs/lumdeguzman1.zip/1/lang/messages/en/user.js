const messages = {
    addNote: 'Add a new note',
    removeNote: 'Remove this note',
    backHome: 'Back to Home',
};
